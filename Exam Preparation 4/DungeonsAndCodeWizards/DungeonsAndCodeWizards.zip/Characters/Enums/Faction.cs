﻿using System;
using System.Collections.Generic;
using System.Text;

namespace DungeonsAndCodeWizards.Characters.Enums
{
    public enum Faction
    {
        CSharp,
        Java
    }
}
