﻿using System;
using System.Collections.Generic;
using System.Text;

public class Point
{
    public double horizontal { get; set; }

    public double vertical { get; set; }

    public Point(double h , double v)
    {
        this.horizontal = h;
        this.vertical = v;
    }
}
