﻿using System;
using System.Globalization;

class Program
{
    static void Main(string[] args)
    {
        //DateTime date1 = DateTime.ParseExact(Console.ReadLine(), "yyyy MM dd", CultureInfo.CurrentCulture);
        //DateTime date2 = DateTime.ParseExact(Console.ReadLine(), "yyyy MM dd", CultureInfo.CurrentCulture);
        //Console.WriteLine(Math.Abs(date1.Subtract(date2).Days));

        DateModifier dateModifier = new DateModifier(Console.ReadLine(), Console.ReadLine());
        Console.WriteLine(dateModifier.diff);
    }
}
