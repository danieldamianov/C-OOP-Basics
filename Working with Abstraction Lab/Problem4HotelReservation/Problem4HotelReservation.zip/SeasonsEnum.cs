﻿using System;
using System.Collections.Generic;
using System.Text;

public enum SeasonsEnum
{
    Autumn = 1,
    Spring,
    Winter,
    Summer
}

public enum DiscountsEnum
{
    None = 0,
    SecondVisit = 10,
    VIP = 20
}

