﻿using System;

class Program
{
    static void Main(string[] args)
    {
        Console.WriteLine(PriceCalculator.GetPrice(Console.ReadLine()));
    }
}

