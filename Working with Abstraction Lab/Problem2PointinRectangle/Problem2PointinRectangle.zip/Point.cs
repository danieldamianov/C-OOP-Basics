﻿using System;
using System.Collections.Generic;
using System.Text;

public class Point
{
    public int Horizontal { get; set; }

    public int Vertical { get; set; }

    public Point(int h , int v)
    {
        this.Horizontal = h;
        this.Vertical = v;
    }
}

