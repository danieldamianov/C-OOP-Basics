﻿using System;
using System.Collections.Generic;
using System.Text;

namespace StorageMaster.Entities.Vehicles
{
    class Truck : Vehicle
    {
        public Truck() : base(5)
        {
        }
    }
}
