﻿using System;
using System.Collections.Generic;
using System.Text;

namespace StorageMaster.Entities.Products
{
    class SolidStateDrive : Product
    {
        public SolidStateDrive(double price) : base(price, 0.7)
        {

        }
    }
}
