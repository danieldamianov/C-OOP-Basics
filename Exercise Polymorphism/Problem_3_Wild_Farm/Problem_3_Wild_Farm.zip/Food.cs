﻿public abstract class Food
{
    public int Quantity;

    public Food(int quantity)
    {
        this.Quantity = quantity;
    }
}

