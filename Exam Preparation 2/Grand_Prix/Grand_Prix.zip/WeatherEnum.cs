﻿internal enum WeatherEnum
{
    Sunny,
    Rainy,
    Foggy
}