﻿public interface IDrivable
{
    string Brake();
    string Gas();
}