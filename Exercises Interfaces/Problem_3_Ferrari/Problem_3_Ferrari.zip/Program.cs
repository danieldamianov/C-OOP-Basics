﻿using System;

public class Program
{
    static void Main(string[] args)
    {
        Console.WriteLine(new Ferari(Console.ReadLine()));
    }
}

