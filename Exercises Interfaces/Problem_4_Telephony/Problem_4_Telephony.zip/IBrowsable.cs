﻿public interface IBrowsable
{
    void Browse(string url);
}

