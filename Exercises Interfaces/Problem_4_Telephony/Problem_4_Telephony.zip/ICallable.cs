﻿public interface ICallable
{
    void Call(string number);
}

