﻿public interface IBirthDayable
{
    string BirthDay { get; }
}

